import 'dart:convert';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;

class Pokemon {
  final String name;
  final int number;
  final String imageUrl;
  final String type;

  Pokemon({
    required this.name,
    required this.number,
    required this.imageUrl,
    required this.type,
  });

  factory Pokemon.fromJson(Map<String, dynamic> json) {
    final int number = int.parse(json['url'].split('/')[6]);
    final imageUrl = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/$number.png';

    // Verifica si 'types' existe y no está vacío, o establece un valor predeterminado si no hay datos de tipo.
    final type = (json['types'] != null && json['types'].isNotEmpty)
        ? json['types'][0]['type']['name']
        : 'Tipo desconocido';

    return Pokemon(
      name: json['name'],
      number: number,
      imageUrl: imageUrl,
      type: type,
    );
  }
}

Future<List<Pokemon>> fetchPokemonList() async {
  final response = await http.get(Uri.parse('https://pokeapi.co/api/v2/pokemon?limit=151'));

  if (response.statusCode == 200) {
    final List<dynamic> data = json.decode(response.body)['results'];

    final List<Pokemon> pokemonList = [];

    for (final pokemonData in data) {
      final pokemon = Pokemon.fromJson(pokemonData);
      pokemonList.add(pokemon);
    }

    return pokemonList;
  } else {
    throw Exception('Failed to load Pokemon');
  }
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pokémon App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const PokemonListScreen(),
    );
  }
}

class PokemonListScreen extends StatefulWidget {
  const PokemonListScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _PokemonListScreenState createState() => _PokemonListScreenState();
}

class _PokemonListScreenState extends State<PokemonListScreen> {
  late Future<List<Pokemon>> pokemonList;
  Pokemon? selectedPokemon;

  @override
  void initState() {
    super.initState();
    pokemonList = fetchPokemonList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pokémon List'),
      ),
      body: Center(
        child: FutureBuilder<List<Pokemon>>(
          future: pokemonList,
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return const CircularProgressIndicator();
            }

            final List<Pokemon> pokemon = snapshot.data ?? [];

            return GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
              ),
              itemCount: pokemon.length,
              itemBuilder: (context, index) {
                final currentPokemon = pokemon[index];
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedPokemon = currentPokemon;
                    });
                  },
                  child: Card(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.network(
                          currentPokemon.imageUrl,
                          fit: BoxFit.cover,
                          width: 100,
                          height: 100,
                        ),
                        Text('${currentPokemon.number}. ${currentPokemon.name}'),
                        Text('Tipo: ${currentPokemon.type}'),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
      bottomSheet: selectedPokemon != null
          ? Container(
              color: Colors.white,
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Detalles de ${selectedPokemon!.name}',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Image.network(
                    selectedPokemon!.imageUrl,
                    fit: BoxFit.cover,
                    width: 100,
                    height: 100,
                  ),
                  Text('Número: ${selectedPokemon!.number}'),
                  Text('Tipo: ${selectedPokemon!.type}'),
                ],
              ),
            )
          : null,
    );
  }
}